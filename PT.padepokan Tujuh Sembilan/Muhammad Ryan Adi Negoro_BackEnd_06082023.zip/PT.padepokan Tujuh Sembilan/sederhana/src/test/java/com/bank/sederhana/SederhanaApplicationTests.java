package com.bank.sederhana;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SederhanaApplicationTests {

	@Test
	void contextLoads() {
	}

}
