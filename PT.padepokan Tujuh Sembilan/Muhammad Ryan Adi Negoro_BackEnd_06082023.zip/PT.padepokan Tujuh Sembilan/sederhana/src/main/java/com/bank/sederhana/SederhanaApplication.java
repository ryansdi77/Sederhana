package com.bank.sederhana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SederhanaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SederhanaApplication.class, args);
	}

}
